#!/usr/bin/env python3
def p(n):
    "Calcula el número de particiones de n."
    return p_act(n, n)

def p_act(n, k):
    '''Calcula el número de particiones 
    de n con longitud acotada por k.'''
    if n == k == 0:
        return 1
    elif n >= 0 and k >= 1:
        return p_act(n, k-1)\
            + p_act(n-k, k)
    else:
        return 0

if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1:
        n = int(sys.argv[1])
        print('p(%d) = %d' % (n, p(n)))