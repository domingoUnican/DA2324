def p_act(n, k):
    if n == k == 0:
        return 1
    elif n >= 0 and k >= 1:
        if n == 0 or k == 1:
            return 1
        elif k > n:
            return p_act(n, n)
        else:
            return p_act(n, k-1)\
                + p_act(n-k, k)
    else:
        return 0